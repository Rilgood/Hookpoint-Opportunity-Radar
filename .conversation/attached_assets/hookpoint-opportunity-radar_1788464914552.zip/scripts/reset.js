import fs from 'node:fs';
import path from 'node:path';
import { config } from '../src/config.js';

const target = path.resolve(config.databasePath);
const allowedRoot = path.resolve(config.rootDir, 'data') + path.sep;
if (!target.startsWith(allowedRoot) || !target.endsWith('.sqlite')) throw new Error(`Refusing to remove database outside ${allowedRoot}`);
for (const suffix of ['', '-shm', '-wal']) {
  const file = `${target}${suffix}`;
  if (fs.existsSync(file)) fs.unlinkSync(file);
}
console.log(`Reset ${target}`);
