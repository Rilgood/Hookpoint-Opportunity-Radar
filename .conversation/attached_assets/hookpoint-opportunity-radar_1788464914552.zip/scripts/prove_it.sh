#!/usr/bin/env sh
set -eu

project_dir="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
proof_dir="$(mktemp -d)"
proof_db="$proof_dir/proof.sqlite"
proof_log="$proof_dir/server.log"
proof_port="${PROOF_PORT:-18787}"
server_pid=""

cleanup() {
  if [ -n "$server_pid" ]; then kill "$server_pid" 2>/dev/null || true; fi
  rm -rf "$proof_dir"
}
trap cleanup EXIT INT TERM

cd "$project_dir"
proof_api_key="proof-only-admin-key-32-bytes-long"
proof_hash_salt="proof-only-hash-salt-is-at-least-32-bytes-long"
proof_webhook_secret="proof-only-webhook-secret-is-at-least-32-bytes-long"
DATABASE_PATH="$proof_db" PORT="$proof_port" AUTH_REQUIRED=true ADMIN_API_KEY="$proof_api_key" HASH_SALT="$proof_hash_salt" CONNECTOR_WEBHOOK_SECRET="$proof_webhook_secret" SCHEDULER_ENABLED=false node src/server.js >"$proof_log" 2>&1 &
server_pid=$!

attempt=0
until curl -fsS "http://127.0.0.1:$proof_port/ready" >"$proof_dir/ready.json" 2>/dev/null; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 20 ]; then
    sed -n '1,160p' "$proof_log"
    exit 1
  fi
  sleep 1
done

if curl -fsS "http://127.0.0.1:$proof_port/api/v1/dashboard" >/dev/null 2>&1; then
  echo "✗ protected API accepted an anonymous request"
  exit 1
fi

curl -fsS -H "x-api-key: $proof_api_key" "http://127.0.0.1:$proof_port/api/v1/dashboard" >"$proof_dir/empty.json"
curl -fsS -X POST -H 'content-type: application/json' -H "x-api-key: $proof_api_key" --data '{"records":[
  {"company":{"name":"Verification Commerce","domain":"verification.test","industry":"Retail","employee_count":90},"source":"meta_ad_library","external_id":"ad-snapshot-1","type":"ad_snapshot","title":"Active ad volume increased with repeated concepts","confidence":0.95,"attributes":{"active_ads":40,"active_ads_delta_pct":80,"duplicate_creative_ratio":0.75,"median_creative_age_days":40}},
  {"company":{"name":"Verification Commerce","domain":"verification.test"},"source":"social_analytics","external_id":"social-snapshot-1","type":"social_metric","title":"Engagement rate declined","confidence":0.9,"attributes":{"engagement_rate_delta_pct":-35}},
  {"company":{"name":"Verification Risk","domain":"verification-risk.test","industry":"Technology","employee_count":500},"source":"risk_feed","external_id":"risk-1","type":"crisis","title":"Material incident requires review","body":"A data breach is under investigation.","confidence":0.95,"attributes":{"severity":"critical"}}
]}' "http://127.0.0.1:$proof_port/api/v1/ingest" >"$proof_dir/run.json"
webhook_body='{"records":[{"company":{"name":"Webhook Verified","domain":"webhook-verified.test"},"external_id":"webhook-1","type":"product_launch","title":"Webhook Verified launches a new service","attributes":{"is_new":true}}]}'
webhook_timestamp="$(date +%s)"
webhook_signature="$(printf '%s' "$webhook_timestamp.proof_webhook.$webhook_body" | openssl dgst -sha256 -hmac "$proof_webhook_secret" -hex | awk '{print $2}')"
curl -fsS -X POST -H 'content-type: application/json' -H "x-api-key: $proof_api_key" -H "x-hookpoint-timestamp: $webhook_timestamp" -H "x-hookpoint-signature: sha256=$webhook_signature" --data "$webhook_body" "http://127.0.0.1:$proof_port/api/v1/webhooks/proof_webhook" >"$proof_dir/webhook.json"
if curl -fsS -X POST -H 'content-type: application/json' -H "x-api-key: $proof_api_key" -H "x-hookpoint-timestamp: $webhook_timestamp" -H "x-hookpoint-signature: sha256=$webhook_signature" --data "$webhook_body" "http://127.0.0.1:$proof_port/api/v1/webhooks/proof_webhook" >/dev/null 2>&1; then
  echo "✗ signed webhook replay was accepted"
  exit 1
fi
curl -fsS -H "x-api-key: $proof_api_key" "http://127.0.0.1:$proof_port/api/v1/dashboard" >"$proof_dir/dashboard.json"
curl -fsS -H "x-api-key: $proof_api_key" "http://127.0.0.1:$proof_port/api/v1/companies?limit=100" >"$proof_dir/companies.json"
curl -fsS -H "x-api-key: $proof_api_key" "http://127.0.0.1:$proof_port/api/v1/signals?status=active" >"$proof_dir/signals.json"
curl -fsS -H "x-api-key: $proof_api_key" "http://127.0.0.1:$proof_port/api/v1/data-quality" >"$proof_dir/quality.json"
curl -fsS -H "x-api-key: $proof_api_key" "http://127.0.0.1:$proof_port/api/v1/export/companies.csv" >"$proof_dir/export.csv"
curl -fsS -X POST -H 'content-type: application/json' -H "x-api-key: $proof_api_key" --data '{"name":"Proof reader","scopes":["read"]}' "http://127.0.0.1:$proof_port/api/v1/api-keys" >"$proof_dir/api-key.json"
reader_key="$(node -e "process.stdout.write(JSON.parse(require('fs').readFileSync('$proof_dir/api-key.json','utf8')).data.token)")"
reader_id="$(node -e "process.stdout.write(JSON.parse(require('fs').readFileSync('$proof_dir/api-key.json','utf8')).data.id)")"
curl -fsS -X POST -H 'content-type: application/json' -H "x-api-key: $proof_api_key" --data '{"name":"Proof writer","scopes":["write"]}' "http://127.0.0.1:$proof_port/api/v1/api-keys" >"$proof_dir/writer-key.json"
writer_key="$(node -e "process.stdout.write(JSON.parse(require('fs').readFileSync('$proof_dir/writer-key.json','utf8')).data.token)")"
writer_id="$(node -e "process.stdout.write(JSON.parse(require('fs').readFileSync('$proof_dir/writer-key.json','utf8')).data.id)")"
curl -fsS -H "x-api-key: $reader_key" "http://127.0.0.1:$proof_port/api/v1/dashboard" >"$proof_dir/reader-dashboard.json"
if curl -fsS -X POST -H 'content-type: application/json' -H "x-api-key: $reader_key" --data '{"records":[]}' "http://127.0.0.1:$proof_port/api/v1/ingest" >/dev/null 2>&1; then
  echo "✗ read-only API key received write access"
  exit 1
fi
if curl -fsS -H "x-api-key: $writer_key" "http://127.0.0.1:$proof_port/api/v1/dashboard" >/dev/null 2>&1; then
  echo "✗ write-only API key received read access"
  exit 1
fi
curl -fsS -X DELETE -H "x-api-key: $proof_api_key" "http://127.0.0.1:$proof_port/api/v1/api-keys/$reader_id" >"$proof_dir/revoked.json"
curl -fsS -X DELETE -H "x-api-key: $proof_api_key" "http://127.0.0.1:$proof_port/api/v1/api-keys/$writer_id" >/dev/null
if curl -fsS -H "x-api-key: $reader_key" "http://127.0.0.1:$proof_port/api/v1/dashboard" >/dev/null 2>&1; then
  echo "✗ revoked API key remained active"
  exit 1
fi

PROOF_DIR="$proof_dir" node --input-type=module <<'NODE'
import fs from 'node:fs';
import path from 'node:path';
const dir = process.env.PROOF_DIR;
const load = (name) => JSON.parse(fs.readFileSync(path.join(dir, name), 'utf8')).data;
const empty = load('empty.json');
const run = load('run.json');
const dashboard = load('dashboard.json');
const companies = load('companies.json').data;
const signals = load('signals.json');
const quality = load('quality.json');
const issuedKey = load('api-key.json');
const checks = [
  ['clean startup contains no companies', empty.companies === 0],
  ['API authentication enforced', true],
  ['canonical observations ingested', run.inserted === 3 && run.rejected === 0],
  ['signed webhook replay blocked', true],
  ['signals inferred', run.signals >= 4],
  ['companies resolved', dashboard.companies === 3],
  ['priority account produced', companies.some((x) => ['hot','warm'].includes(x.opportunity_tier))],
  ['crisis suppression works', companies.some((x) => x.opportunity_tier === 'suppressed')],
  ['evidence is queryable', signals.length >= 4],
  ['quality telemetry is populated', quality.observations.total === 4 && quality.rejections.total === 0],
  ['scoped API key lifecycle works', issuedKey.scopes.length === 1 && issuedKey.scopes[0] === 'read'],
  ['CSV export produced', fs.readFileSync(path.join(dir, 'export.csv'), 'utf8').includes('opportunity_score')]
];
for (const [label, passed] of checks) console.log(`${passed ? '✓' : '✗'} ${label}`);
if (checks.some(([, passed]) => !passed)) process.exit(1);
NODE

kill "$server_pid" 2>/dev/null || true
wait "$server_pid" 2>/dev/null || true
server_pid=""

gate_port=$((proof_port + 1))
NODE_ENV=production DATABASE_PATH="$proof_dir/ephemeral.sqlite" PORT="$gate_port" AUTH_REQUIRED=true ALLOW_EPHEMERAL_STORAGE=false ADMIN_API_KEY="$proof_api_key" HASH_SALT="$proof_hash_salt" CONNECTOR_WEBHOOK_SECRET="$proof_webhook_secret" SCHEDULER_ENABLED=false node src/server.js >"$proof_dir/gate.log" 2>&1 &
server_pid=$!
attempt=0
until curl -fsS "http://127.0.0.1:$gate_port/health" >/dev/null 2>&1; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 20 ]; then
    sed -n '1,160p' "$proof_dir/gate.log"
    exit 1
  fi
  sleep 1
done
ready_status="$(curl -sS -o "$proof_dir/gate-ready.json" -w '%{http_code}' "http://127.0.0.1:$gate_port/ready")"
api_status="$(curl -sS -o "$proof_dir/gate-api.json" -w '%{http_code}' -H "x-api-key: $proof_api_key" "http://127.0.0.1:$gate_port/api/v1/dashboard")"
if [ "$ready_status" != "503" ] || [ "$api_status" != "503" ]; then
  echo "✗ unsafe production storage did not fail closed"
  exit 1
fi
echo "✓ unsafe production storage fails closed"

echo "Golden path passed with an empty start and connector-neutral ingestion."
