// Vercel's local filesystem is ephemeral. Readiness remains failed until a
// durable storage adapter is attached or ephemeral operation is explicitly allowed.
process.env.DATABASE_PATH ||= '/tmp/hookpoint-opportunity-radar.sqlite';
process.env.SCHEDULER_ENABLED ||= 'false';

const [{ getDb }, { createApp }] = await Promise.all([
  import('../src/db/index.js'),
  import('../src/app.js')
]);

const db = getDb();
const handler = createApp(db, { serveStaticAssets: false });

export default handler;
