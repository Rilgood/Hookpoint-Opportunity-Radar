const state = {
  readiness: null, meta: null, summary: null, quality: null, companies: [], priorityCompanies: [], companyPage: { page: 1, pages: 1, total: 0 },
  signals: [], connectors: [], tier: '', search: '', view: 'overview'
};
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
let apiKey = sessionStorage.getItem('hookpoint_api_key') || '';
let authPrompt = null;

async function request(path, options = {}) {
  const keyAtRequest = apiKey;
  const response = await fetch(path, {
    ...options,
    headers: { ...(options.body ? { 'content-type': 'application/json' } : {}), ...(apiKey ? { 'x-api-key': apiKey } : {}), ...(options.headers || {}) },
    body: options.body && typeof options.body !== 'string' ? JSON.stringify(options.body) : options.body
  });
  if (response.status === 401 && options.retryAuth !== false) {
    if (apiKey && apiKey !== keyAtRequest) return request(path, { ...options, retryAuth: false });
    const supplied = await acquireApiKey();
    if (supplied) {
      return request(path, { ...options, retryAuth: false });
    }
  }
  if (!response.ok) {
    const payload = await response.json().catch(() => ({}));
    throw new Error(payload.error?.message || `Request failed (${response.status})`);
  }
  if (options.raw) return response;
  return (await response.json()).data;
}

async function acquireApiKey() {
  if (!authPrompt) {
    authPrompt = Promise.resolve().then(() => {
      const supplied = window.prompt('Enter your Hook Point Radar API key')?.trim() || '';
      if (supplied) {
        apiKey = supplied;
        sessionStorage.setItem('hookpoint_api_key', apiKey);
      }
      return supplied;
    }).finally(() => { authPrompt = null; });
  }
  return authPrompt;
}

function companyPath() {
  const query = new URLSearchParams({ page: String(state.companyPage.page), limit: '50' });
  if (state.tier) query.set('tier', state.tier);
  if (state.search) query.set('q', state.search);
  return `/api/v1/companies?${query}`;
}

async function load() {
  try {
    const readinessResponse = await fetch('/ready', { cache: 'no-store' });
    const readinessPayload = await readinessResponse.json();
    state.readiness = readinessPayload.data;
    if (!readinessResponse.ok) {
      render();
      toast('Runtime configuration must be completed before the API can accept traffic.', true);
      return;
    }
    const [meta, summary, companies, priority, signals, connectors, quality] = await Promise.all([
      request('/api/v1/meta'), request('/api/v1/dashboard'), request(companyPath()),
      request('/api/v1/companies?limit=10&min_score=32'), request('/api/v1/signals?status=active&limit=100'),
      request('/api/v1/connectors'), request('/api/v1/data-quality')
    ]);
    Object.assign(state, { meta, summary, companies: companies.data, priorityCompanies: priority.data, companyPage: companies, signals, connectors, quality });
    render();
  } catch (error) { toast(error.message, true); }
}

async function loadCompanies() {
  try {
    const result = await request(companyPath());
    state.companies = result.data;
    state.companyPage = result;
    renderTable();
  } catch (error) { toast(error.message, true); }
}

function render() {
  renderRuntime(); renderOnboarding(); renderMetrics(); renderPriority(); renderTiers(); renderIndustries();
  renderRecentSignals(); renderTable(); renderSignalFeed(); renderConnectors(); renderQuality();
}

function renderRuntime() {
  const banner = $('#runtimeBanner');
  const issues = state.readiness?.issues || [];
  const ephemeral = (state.meta?.storage_mode || state.readiness?.storage_mode) === 'ephemeral_sqlite';
  banner.hidden = !ephemeral && !issues.length;
  if (issues.length) banner.textContent = `Runtime not ready: ${issues.map((issue) => issue.message).join(' ')}`;
  else if (ephemeral) banner.textContent = 'Ephemeral storage detected. Do not enable production connectors until durable storage is attached.';
}

function renderOnboarding() { $('#onboarding').hidden = Number(state.summary?.companies || 0) !== 0; }

function renderMetrics() {
  const s = state.summary || {};
  $('#metrics').innerHTML = [
    ['Priority accounts', (s.hot || 0) + (s.warm || 0), '↗', `${s.hot || 0} hot now`],
    ['Active signals', s.active_signals || 0, '⌾', `${s.new_signals_7d || 0} seen this week`],
    ['Companies watched', s.companies || 0, '◫', `Average score ${s.average_score || 0}`],
    ['Data sources ready', s.connectors?.configured || 0, '⌁', `${s.connectors?.total || 0} registered`]
  ].map(([label,value,icon,trend]) => `<article class="metric"><div class="metric-top"><span class="metric-icon">${icon}</span><span class="metric-trend">${escapeHtml(trend)}</span></div><div class="metric-value">${format(value)}</div><div class="metric-label">${label}</div></article>`).join('');
}

function renderPriority() {
  const items = state.priorityCompanies.filter((item) => ['hot','warm','watch'].includes(item.opportunity_tier) && !['rejected','customer','lost','disqualified'].includes(item.status)).slice(0, 6);
  $('#priorityAccounts').innerHTML = items.length ? items.map((item) => `<div class="priority-item" data-company="${item.id}"><div class="avatar">${initials(item.name)}</div><div><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.industry)} · ${tierLabel(item.opportunity_tier)}</small></div><div class="score">${Math.round(item.opportunity_score)}</div><span class="chevron">›</span></div>`).join('') : empty('No qualified opportunities yet. Connect evidence sources to begin scoring.');
}

function renderTiers() {
  const tiers = ['hot','warm','watch','cold','suppressed'];
  const counts = Object.fromEntries((state.summary?.tiers || []).map((item) => [item.tier, item.count]));
  const max = Math.max(1, ...Object.values(counts));
  $('#tierChart').innerHTML = tiers.map((tier) => `<div class="tier-row"><span>${tierLabel(tier)}</span><div class="bar"><i class="${tier}" style="width:${((counts[tier] || 0) / max) * 100}%"></i></div><strong>${counts[tier] || 0}</strong></div>`).join('');
}

function renderIndustries() {
  $('#industries').innerHTML = (state.summary?.top_industries || []).slice(0, 5).map((item) => `<div class="industry-row"><span>${escapeHtml(item.industry)}</span><span>${item.average_score}</span></div>`).join('') || empty('No industry data yet.');
}

function renderRecentSignals() {
  $('#recentSignals').innerHTML = state.signals.slice(0, 6).map((signal) => `<article class="signal-card" data-company="${signal.company_id}"><div class="signal-meta"><strong>${escapeHtml(signal.company_name)}</strong><span class="signal-weight">+${Math.round(signal.contribution)}</span></div><span class="tier-badge ${signal.opportunity_tier}">${tierLabel(signal.opportunity_tier)}</span><p>${escapeHtml(signal.summary)}</p></article>`).join('') || empty('No signals have been detected.');
}

function renderTable() {
  const page = state.companyPage;
  $('#resultCount').textContent = `${format(page.total || 0)} account${page.total === 1 ? '' : 's'}`;
  $('#companyTable').innerHTML = state.companies.length ? state.companies.map((item) => `<tr data-company="${item.id}"><td><div class="company-cell"><div class="avatar">${initials(item.name)}</div><div><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.domain || [item.city,item.state].filter(Boolean).join(', '))}</small></div></div></td><td>${escapeHtml(item.industry)}</td><td><span class="tier-badge ${item.opportunity_tier}">${tierLabel(item.opportunity_tier)}</span> <strong>${Math.round(item.opportunity_score)}</strong></td><td>${tierLabel(item.status)}</td><td>${profile(item)}</td><td>${tierLabel(item.monitoring_tier)}</td><td>${relative(item.last_observed_at)}</td><td>›</td></tr>`).join('') : `<tr><td colspan="8">${empty('No accounts match this filter.')}</td></tr>`;
  $('#pageStatus').textContent = page.total ? `Page ${page.page} of ${page.pages}` : 'No results';
  $('#previousPage').disabled = page.page <= 1;
  $('#nextPage').disabled = page.page >= page.pages;
}

function renderSignalFeed() {
  $('#signalFeed').innerHTML = state.signals.map((signal) => `<article class="feed-item" data-company="${signal.company_id}"><i class="feed-dot"></i><div><h3>${escapeHtml(signal.label)} · ${escapeHtml(signal.company_name)}</h3><p>${escapeHtml(signal.summary)}</p><div class="feed-tags"><span class="tag">${escapeHtml(signal.category)}</span><span class="tag">${signal.source_count} source${signal.source_count === 1 ? '' : 's'}</span><span class="tag">${relative(signal.last_seen_at)}</span></div></div><div class="feed-score"><strong>+${Math.round(signal.contribution)}</strong><small>contribution</small></div></article>`).join('') || empty('No evidence yet.');
}

function renderConnectors() {
  const connected = state.connectors.filter((item) => item.configured).length;
  const implemented = state.connectors.filter((item) => item.implemented).length;
  $('#connectorSummary').innerHTML = `<span class="summary-chip"><strong>${state.connectors.length}</strong> registered</span><span class="summary-chip"><strong>${implemented}</strong> runnable adapters</span><span class="summary-chip"><strong>${connected}</strong> credential-ready</span>`;
  $('#connectorGrid').innerHTML = state.connectors.map((item) => {
    const status = !item.implemented ? 'pending' : item.status === 'error' || item.status === 'degraded' ? 'missing' : item.configured ? 'ready' : 'missing';
    const label = !item.implemented ? 'Adapter pending' : item.status === 'error' ? 'Run failed' : item.status === 'degraded' ? 'Partial run' : item.configured ? (item.enabled ? 'Enabled' : 'Ready') : 'Needs config';
    const disabled = !item.configured || !item.implemented || item.mode === 'push';
    return `<article class="connector"><div class="connector-head"><div class="connector-icon">${escapeHtml(item.provider.slice(0,3))}</div><span class="status ${status}">${label}</span></div><h3>${escapeHtml(item.label)}</h3><p>${escapeHtml(item.category)} · ${escapeHtml(item.cadence)} · ${item.run_count} runs</p><div class="connector-foot"><span class="muted">${escapeHtml(item.config?.costTier || 'variable')} cost</span><button class="toggle ${item.enabled ? 'on' : ''}" data-connector="${escapeHtml(item.connector_key)}" aria-label="Toggle ${escapeHtml(item.label)}" ${disabled ? 'disabled' : ''}></button></div></article>`;
  }).join('');
}

function renderQuality() {
  const quality = state.quality || {};
  const observations = quality.observations || {};
  const rejections = quality.rejections || {};
  const identity = quality.identity || {};
  const health = quality.connector_health || {};
  $('#qualityMetrics').innerHTML = [
    ['Observations', observations.total || 0, `${observations.ingested_24h || 0} ingested in 24h`],
    ['Rejected records', rejections.total || 0, `${rejections.rejection_rate_7d || 0}% seven-day rate`],
    ['Identity review', identity.needs_review || 0, `${identity.missing_domain || 0} missing domains`],
    ['Connector issues', (health.errors || 0) + (health.degraded || 0), `${health.enabled || 0} enabled`]
  ].map(([label,value,detail]) => `<article class="metric"><div class="metric-value">${format(value)}</div><div class="metric-label">${label}</div><p class="quality-detail">${escapeHtml(detail)}</p></article>`).join('');
  $('#sourceQuality').innerHTML = (quality.source_freshness || []).map((item) => `<tr><td>${escapeHtml(item.source.replaceAll('_',' '))}</td><td>${format(item.observations)}</td><td>${Math.round(Number(item.average_confidence || 0) * 100)}%</td><td>${relative(item.latest_retrieval)}</td></tr>`).join('') || `<tr><td colspan="4">${empty('Source health appears after the first real observation is ingested.')}</td></tr>`;
}

async function openCompany(companyId) {
  try {
    const detail = await request(`/api/v1/companies/${companyId}`);
    const company = detail.company;
    $('#drawerContent').innerHTML = `<div class="detail-header"><p class="eyebrow">${escapeHtml(company.industry)} · ${tierLabel(company.monitoring_tier)} MONITORING</p><h2>${escapeHtml(company.name)}</h2><p>${escapeHtml(company.domain || '')} ${company.city ? `· ${escapeHtml([company.city,company.state].filter(Boolean).join(', '))}` : ''}</p><span class="identity-note">Identity ${Math.round(Number(company.identity_confidence || 0) * 100)}% · ${tierLabel(company.identity_method)}</span></div><div class="detail-score"><div class="score-ring" style="--score:${company.opportunity_score}%"><strong>${Math.round(company.opportunity_score)}</strong></div><div class="dimensions">${dimension('Fit',company.fit_score)}${dimension('Need',company.need_score)}${dimension('Intent',company.intent_score)}${dimension('Timing',company.timing_score)}</div></div><div class="outcome-actions" data-outcome-company="${company.id}"><button class="outcome-button" data-outcome="accepted">Accept lead</button><button class="outcome-button" data-outcome="contacted">Contacted</button><button class="outcome-button" data-outcome="meeting">Meeting booked</button><button class="outcome-button" data-outcome="opportunity">Opportunity</button><button class="outcome-button" data-outcome="won">Won</button><button class="outcome-button" data-outcome="rejected">Reject</button></div>${detail.recommendation ? `<article class="recommendation"><p class="eyebrow">RECOMMENDED ACTION</p><h3>${escapeHtml(detail.recommendation.offer)}</h3><p>${escapeHtml(detail.recommendation.rationale)}</p><p>${escapeHtml(detail.recommendation.outreach_angle)}</p><p class="next">${escapeHtml(detail.recommendation.next_action)}</p></article>` : ''}<section class="detail-section"><h3>Active signals</h3>${detail.signals.filter((item) => item.status === 'active').map((item) => `<div class="evidence"><strong>${escapeHtml(item.label)} <span class="signal-weight">+${Math.round(item.contribution)}</span></strong><p>${escapeHtml(item.summary)}</p><span class="tag">${item.source_count} source${item.source_count === 1 ? '' : 's'}</span></div>`).join('') || empty('No active signals.')}</section><section class="detail-section"><h3>Evidence</h3>${detail.observations.slice(0,8).map((item) => `<div class="evidence"><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.source.replaceAll('_',' '))} · ${relative(item.observed_at)} · ${Math.round(Number(item.confidence) * 100)}% confidence</p>${item.url ? `<a href="${safeUrl(item.url)}" target="_blank" rel="noreferrer">Open source ↗</a>` : ''}</div>`).join('') || empty('No evidence stored.')}</section>${detail.people.length ? `<section class="detail-section"><h3>Potential buyers</h3>${detail.people.map((item) => `<div class="person"><strong>${escapeHtml(item.full_name)}</strong><span>${escapeHtml(item.title || '')}</span></div>`).join('')}</section>` : ''}`;
    $('#drawerBackdrop').hidden = false;
    $('#detailDrawer').classList.add('open');
    $('#detailDrawer').setAttribute('aria-hidden','false');
  } catch (error) { toast(error.message, true); }
}

function closeDrawer() {
  $('#detailDrawer').classList.remove('open');
  $('#detailDrawer').setAttribute('aria-hidden','true');
  setTimeout(() => { $('#drawerBackdrop').hidden = true; }, 220);
}

async function toggleConnector(button) {
  const key = button.dataset.connector;
  const enabled = !button.classList.contains('on');
  button.disabled = true;
  try { await request(`/api/v1/connectors/${key}`, { method: 'PATCH', body: { enabled } }); toast(`${key} ${enabled ? 'enabled' : 'disabled'}`); await load(); }
  catch (error) { toast(error.message, true); button.disabled = false; }
}

async function recordOutcome(button) {
  const companyId = button.closest('[data-outcome-company]').dataset.outcomeCompany;
  const outcome = button.dataset.outcome;
  button.disabled = true;
  try { await request(`/api/v1/companies/${companyId}/outcomes`, { method: 'POST', body: { outcome_type: outcome } }); toast(`${tierLabel(outcome)} recorded`); await load(); }
  catch (error) { toast(error.message, true); }
  finally { button.disabled = false; }
}

async function exportCsv() {
  const button = $('#exportButton');
  button.disabled = true;
  try {
    const query = new URLSearchParams();
    if (state.tier) query.set('tier', state.tier);
    const response = await request(`/api/v1/export/companies.csv?${query}`, { raw: true });
    const url = URL.createObjectURL(await response.blob());
    const link = document.createElement('a');
    link.href = url; link.download = 'hookpoint-opportunities.csv'; link.click();
    URL.revokeObjectURL(url);
  } catch (error) { toast(error.message, true); }
  finally { button.disabled = false; }
}

function setView(view) {
  state.view = view;
  $$('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.view === view));
  $$('.view').forEach((item) => item.classList.remove('active'));
  $(`#${view}View`).classList.add('active');
  const titles = {
    overview:['MARKET INTELLIGENCE','Opportunity overview'], opportunities:['PRIORITIZED ACCOUNTS','Warm-lead pipeline'],
    signals:['REAL-WORLD CHANGE','Signal feed'], connectors:['INGESTION LAYER','Data sources'], quality:['TRUST & LINEAGE','Data quality']
  };
  $('#viewEyebrow').textContent = titles[view][0];
  $('#viewTitle').textContent = titles[view][1];
}

document.addEventListener('click', (event) => {
  const nav = event.target.closest('[data-view]'); if (nav) setView(nav.dataset.view);
  const jump = event.target.closest('[data-jump]'); if (jump) setView(jump.dataset.jump);
  const company = event.target.closest('[data-company]'); if (company) openCompany(company.dataset.company);
  const pill = event.target.closest('[data-tier]');
  if (pill) { state.tier = pill.dataset.tier; state.companyPage.page = 1; $$('.pill').forEach((item) => item.classList.toggle('active', item === pill)); loadCompanies(); }
  const connector = event.target.closest('[data-connector]'); if (connector) toggleConnector(connector);
  const outcome = event.target.closest('[data-outcome]'); if (outcome) recordOutcome(outcome);
});

let searchTimer;
$('#searchInput').addEventListener('input', (event) => {
  state.search = event.target.value.trim(); state.companyPage.page = 1;
  if (state.view !== 'opportunities') setView('opportunities');
  clearTimeout(searchTimer); searchTimer = setTimeout(loadCompanies, 250);
});
$('#previousPage').addEventListener('click', () => { state.companyPage.page -= 1; loadCompanies(); });
$('#nextPage').addEventListener('click', () => { state.companyPage.page += 1; loadCompanies(); });
$('#exportButton').addEventListener('click', exportCsv);
$('#drawerClose').addEventListener('click', closeDrawer);
$('#drawerBackdrop').addEventListener('click', closeDrawer);
document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeDrawer(); });

function dimension(label,value) { return `<div class="dimension"><small><span>${label}</span><strong>${Math.round(value)}</strong></small><div class="bar"><i class="hot" style="width:${value}%"></i></div></div>`; }
function profile(item) { const value = (item.need_score + item.intent_score + item.timing_score) / 3; return `<div class="score-profile" title="Signal strength ${Math.round(value)}">${[15,30,45,60,75].map((threshold,index) => `<i class="${value >= threshold ? 'on' : ''}" style="height:${7+index*3}px"></i>`).join('')}</div>`; }
function tierLabel(value='') { return String(value).replaceAll('_',' ').replace(/\b\w/g,(character)=>character.toUpperCase()); }
function initials(value='') { return escapeHtml(value.split(/\s+/).slice(0,2).map((word)=>word[0]).join('').toUpperCase()); }
function format(value) { return Number(value || 0).toLocaleString(); }
function relative(value) { if (!value) return 'Never'; const days = Math.floor((Date.now()-new Date(value).getTime())/86400000); return days <= 0 ? 'Today' : days === 1 ? 'Yesterday' : `${days}d ago`; }
function empty(message) { return `<div class="empty">${escapeHtml(message)}</div>`; }
function safeUrl(value) { try { const url = new URL(value); return ['http:','https:'].includes(url.protocol) ? escapeHtml(url.toString()) : '#'; } catch { return '#'; } }
function escapeHtml(value='') { return String(value ?? '').replace(/[&<>'"]/g,(character)=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[character])); }
let toastTimer;
function toast(message,error=false) { const node=$('#toast'); node.textContent=message; node.classList.toggle('error',error); node.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>node.classList.remove('show'),3200); }

load();
